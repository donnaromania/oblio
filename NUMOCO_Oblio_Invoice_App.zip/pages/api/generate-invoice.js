import axios from "axios";

export default async function handler(req, res) {
  const { orderId } = req.body;

  const invoiceData = {
    companyVatCode: "RO12345678",
    seriesName: "NUMOCO",
    partner: {
      name: "Popescu Ana",
      county: "București",
      city: "București",
      address: "Str. Exemplu 12",
      vatCode: "",
      saveToDb: true,
    },
    products: [
      {
        name: "Produs test",
        code: "SKU123",
        quantity: 1,
        price: 320,
        currency: "RON",
      },
    ],
  };

  try {
    const response = await axios.post(
      "https://api.oblio.eu/partner/documents",
      invoiceData,
      {
        headers: {
          "X-Api-Token": "c31365c13adb4aac7df0e86fbe0b74646355de6a",
          "X-Api-Secret-Key": "cb8849c3efc662d2c73a0af697e61dca0c98c294",
        },
      }
    );
    const { documentUrl } = response.data;
    res.status(200).json({ invoiceLink: documentUrl });
  } catch (error) {
    console.error("Eroare Oblio:", error.response?.data || error.message);
    res.status(500).json({ error: "Eroare Oblio" });
  }
}