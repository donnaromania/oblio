export default async function handler(req, res) {
  const mockOrders = [
    {
      id: "1234",
      client: "Popescu Ana",
      email: "ana@email.com",
      total: "320 RON",
      status: "factura generata",
    },
    {
      id: "1235",
      client: "Ionescu Vlad",
      email: "vlad@email.com",
      total: "189 RON",
      status: "in asteptare",
    },
  ];
  res.status(200).json(mockOrders);
}