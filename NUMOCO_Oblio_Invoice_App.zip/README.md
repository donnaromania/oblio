# Oblio Invoice App for Shopify

1. Rulează `npm install`
2. Apoi `npm run dev`
3. Creează aplicația în Shopify Admin și setează URL-ul local: `https://localhost:3000`

Aplicația va genera automat facturi în Oblio pentru comenzile noi.